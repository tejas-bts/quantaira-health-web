import React from 'react';

const NewPassword = () => {
  return <div>NewPassword</div>;
};

export default NewPassword;
