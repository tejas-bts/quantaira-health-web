import React from 'react';

const AddAlarm = () => {
  return <div>Add Alarm</div>;
};

export default AddAlarm;
