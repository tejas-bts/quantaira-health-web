import React from 'react';

const ShowAlarms = () => {
  return <div>Show Alarms</div>;
};

export default ShowAlarms;
