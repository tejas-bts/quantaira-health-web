import React from 'react';

const Spinner = () => {
  return <div className="quantaira-spinner-container"></div>;
};

export default Spinner;
