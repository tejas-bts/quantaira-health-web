import React from 'react';

const RR = () => {
  return <div>RR</div>;
};

export default RR;
